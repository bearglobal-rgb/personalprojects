# Verification notes — v1.3

- Source baseline: 0e1d6975b7efa1fcdcbf1a062c771238d37d38b3. The source snapshot matches this revision; hashes are in source-manifest.json.
- The Founder line uses the confirmed mobile sticky geometry on desktop too. Eighteen relevant Chromium tests passed, with two device-specific skips. Checks include upward wheel reversals from the rail end and mobile touch restarts with animation frames paused, endpoints, direct fallback and reduced motion.
- The owner confirmed zero lag on the physical phone before this desktop extension. Latest desktop feedback remains pending.
- Typography/component measurements were collected at 3015dfd at 390, 640, 768, 1024 and 1440 CSS px; these visual tokens are unchanged.
- PDF remains 12 A4 pages; HTML embeds its fonts and monogram. The written glass recipe is authoritative because print rendering may vary.
- Some photographs remain remote URLs. Local supplied assets and font licenses are included.

- Monogram loading: ten targeted desktop/mobile checks passed, including cache-disabled visits to all four pages, real Apply for Black navigation, SVG decoding without JavaScript, zero external master-SVG requests, and matching artwork paths/viewBox/transforms.
