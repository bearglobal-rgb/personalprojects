# Verification notes — v1.1

- Source baseline: 827a4d0f77d453ae55a1891917445db7997afd67. The source snapshot matches this revision; hashes are in source-manifest.json.
- Typography/component measurements in computed-styles.json were collected at the preceding 3015dfd revision at 390, 640, 768, 1024 and 1440 CSS px. Those visual tokens are unchanged by the mobile line fix.
- The mobile Founder tip now uses clipped native sticky geometry, replacing the sampled scroll timeline. Nineteen relevant Chromium tests passed (one desktop-only skip), including touch restarts/reversals with animation frames paused. Chromium and WebKit checks reported zero immediate geometry error on normal and iOS-style contained scrollers. Physical iPhone confirmation remains outstanding.
- PDF: 12 A4 pages, selectable text and embedded fonts. Page bounds were checked; visual specimens are documentation rather than screenshots of every live state.
- HTML embeds fonts and monogram. Print/PDF glass rendering may vary; the written CSS recipe is authoritative.
- Some photographs remain remote URLs. Supplied local assets and font licenses are included.
- Download page: https://bearglobal-rgb.github.io/personalprojects/brand-kit/
