# Verification notes — v1.6

- Source baseline: 75a4f2090ebf4e73766ba8b8b469f1d7c96c3073. The source snapshot matches this revision; hashes are in source-manifest.json.
- The Founder line uses the confirmed mobile sticky geometry on desktop too. Eighteen relevant Chromium tests passed, with two device-specific skips. Checks include upward wheel reversals from the rail end and mobile touch restarts with animation frames paused, endpoints, direct fallback and reduced motion.
- The owner confirmed zero lag on the physical phone before this desktop extension. Latest desktop feedback remains pending.
- Typography/component measurements were collected at 3015dfd at 390, 640, 768, 1024 and 1440 CSS px; these visual tokens are unchanged.
- PDF remains 12 A4 pages; HTML embeds its fonts and monogram. The written glass recipe is authoritative because print rendering may vary.
- All current website photographs are now local. Supplied assets and font licenses are included.

- Monogram loading: ten targeted desktop/mobile checks passed, including cache-disabled visits to all four pages, real Apply for Black navigation, SVG decoding without JavaScript, zero external master-SVG requests, and matching artwork paths/viewBox/transforms.

- Beta disclosure: 20 relevant application, checkout and homepage checks passed. Placement, readable layout and lack of horizontal overflow checked at 320, 390 and 1440px; desktop offer buttons remain aligned. The floating banner and preview restrictions remain unchanged.

- Photo migration: all five downloads match recorded SHA-256 source hashes. Twelve relevant desktop/mobile checks passed, including decoding every page photo with Whop blocked and preserving the approved laptop-screen composite. Public page/JavaScript exposed no larger photo variants. Served images are not 4K masters.

- Information pages: 54 relevant Chromium checks passed across desktop/mobile projects. Coverage includes all eight route footers, 320–1440px layouts, preview non-submission, essential-only persistence/reset/cross-tab sync, corrupt/blocked storage, JavaScript-disabled behavior, iPhone-user-agent anchor scrolling and existing signup/header/footer/CTA regressions. No physical Safari claim.
