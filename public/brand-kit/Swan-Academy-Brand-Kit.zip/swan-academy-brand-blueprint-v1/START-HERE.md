# Swan Academy brand kit · v1.6

1. Read Swan-Academy-Brand-Blueprint.pdf for the visual reference.
2. Give a new assistant AI-HANDOFF.md first, then BRAND-GUIDELINES.md and design-tokens.json.
3. Keep computed-styles.json and source-snapshot/ available for exact implementation details.
4. Use the original SVGs, variable WOFF2 fonts and licenses in assets/.
5. Use brand-blueprint.html as the editable visual guide. Its layout is documentation, not a replacement site.
6. The ZIP contains the entire kit. Unzip before browsing its folders.

The source snapshot is included for portability; it excludes node_modules, dist, credentials and Git history.
All current website photographs are included locally at their available source resolution. They are not 4K masters. The site does not connect email, applications or payments.

Suggested low-context workflow: start a fresh chat in the same project, attach this handoff and brand guide,
and state the next task. You do not need a new project merely because one conversation is long.
An assistant can produce summaries and files but cannot delete previous messages or guarantee cross-chat memory.
Platforms may compact or select context automatically; token usage also depends on model, caching and product behavior.

The PDF summarizes the specification. The Markdown, JSON and source snapshot retain the exact details.
Do not load every source file into a prompt at once. Start with the short handoff and retrieve only what the task needs.

Online access: https://bearglobal-rgb.github.io/personalprojects/brand-kit/
Version 1.6 extends the confirmed mobile sticky geometry to desktop and includes the revised source.

Version 1.6 preserves the monogram artwork while embedding it in the shared stylesheet to remove the delayed SVG request.

Version 1.6 adds the approved Black beta label and pre-application/pre-payment explanations.

Version 1.6 removes Whop photo dependencies while preserving the served files byte-for-byte.

Version 1.6 adds the four branded information pages, footer links and essential-only preference controls. Legal/operator and support details remain working drafts.
